-- CREATE DATABASE Galactic_Company;
-- USE Galactic_Company;
-- ALTER DATABASE Galactic_Company SET OFFLINE;
-- ALTER DATABASE Galactic_Company SET OFFLINE WITH ROLLBACK IMMEDIATE;
-- DROP DATABASE Galactic_Company;

-- CREATE TABLE IT_Department(
--     Employee_ID INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
--     Employee_Name NVARCHAR(60) NULL,
--     Age INT NOT NULL,
--     Country NVARCHAR(60) NULL,
--     Job_ID INT UNIQUE FOREIGN KEY (Job_ID) REFERENCES Job(Job_ID) -- one to one relation
--     -- Job_ID INT FOREIGN KEY (Job_ID) REFERENCES Job(Job_ID) -- one to many
-- );

-- CREATE TABLE Job(
--     Job_ID INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
--     Job_Name NVARCHAR(60) NULL,
--     Salary FLOAT NOT NULL,
--     Grade INT NOT NULL
-- );

-- Junction table for many to many relation
-- CREATE TABLE Employee_Job(
--     Employee_ID INT,
--     Job_ID INT,
--     PRIMARY KEY (Employee_ID, Job_ID),
--     FOREIGN KEY (Employee_ID) REFERENCES IT_Department(Employee_ID),
--     FOREIGN KEY (Job_ID) REFERENCES Job(Job_ID)
-- );

-- ALTER TABLE IT_Department
-- ADD PhoneNumber INT NULL, --not if not null then you have to do DEFAULT 0;
-- Galactic_Date DATETIME NOT NULL DEFAULT GETDATE();

-- UPDATE IT_Department SET Age = 20 WHERE Employee_ID = 1;
-- UPDATE IT_Department SET Age = 20, Employee_Name = "Mohamed" WHERE Employee_ID = 1;

-- DROP TABLE IT_Department;
-- DELETE IT_Department WHERE Employee_ID = 3;

-- INSERT INTO IT_Department (Employee_Name, Age, Country, PhoneNumber, Job_ID)
-- VALUES
--     ('Ahmed Mohamed', 20, Egypt, 123456789012, 1),
--     ('Mohamed Ahmed', 22, Egypt, 210987654321, 2),
--     ('Jack Black', 24, Egypt, 238759829013, 3),
--     ('Jim Carry', 26, Egypt, 103856297352, 4),
--     ('Walter White', 28, Egypt, 664837562846, 5),
--     ('Adam Black', 30, Egypt, 984382834475, 6);

-- INSERT INTO Job (Job_Name, Salary, Grade)
-- VALUES
--     ('Help Desk', 20000, 1),
--     ('Developer', 22000, 16),
--     ('Analyst', 24000, 17),
--     ('Team Head', 26000, 18,
--     ('Manager', 28000, 19),
--     ('Department Head', 20);

-- INSERT INTO Employee_Job (Employee_ID, Job_ID) 
-- VALUES 
--     (1, 1),
--     (2, 2),
--     (3, 3),
--     (4, 4),
--     (5, 5),
--     (6, 6);

-- SELECT * FROM IT_Department;
-- SELECT * FROM IT_Department WHERE Employee_ID = 4;
-- SELECT * FROM IT_Department WHERE Employee_Name = "Ahmed" AND PhoneNumber = 123456789012;
-- SELECT DISTINCT Employee_Name FROM IT_Department;

-- SELECT COUNT(*) FROM IT_Department;
-- SELECT Employee_Name, COUNT(*) FROM IT_Department GROUP BY Employee_Name;

-- SELECT MIN(Age) FROM IT_Department;
-- SELECT MAX(Age) IT_Department;
-- SELECT SUM(Age) IT_Department;
-- SELECT MAX(Age), Employee_ID IT_Department GROUP BY Employee_ID;
-- SELECT SUM(Age), Employee_Name IT_Department GROUP BY Employee_Name;

-- SELECT AVG(Age) AS average_age
-- FROM IT_Department;

-- Ask AI to EXPLAIN the following functions
-- SELECT CEILING;
-- SELECT ROUND;
-- SELECT FLOOR;
-- SELECT MONTH;
-- SELECT YEAR;
-- SELECT DAY;

-- SELECT * FROM IT_Department
-- INNER JOIN Job on IT_Department.Job_ID=Job.Job_ID; -- one to one and one to many (note join == inner join)

-- SELECT * FROM IT_Department
-- INNER JOIN Employee_Job ON IT_Department.Employee_ID = Employee_Job.Employee_ID
-- INNER JOIN Job ON Employee_Job.Job_ID = Job.Job_ID; -- many to many (note join == inner join)

-- SELECT * FROM IT_Department
-- LEFT OUTER JOIN Job ON IT_Department.Job_ID = Job.Job_ID;

-- SELECT * FROM IT_Department
-- LEFT OUTER JOIN Employee_Job ON IT_Department.Employee_ID = Employee_Job.Employee_ID
-- LEFT OUTER JOIN Job ON Employee_Job.Job_ID = Job.Job_ID;

-- SELECT * FROM IT_Department
-- RIGHT OUTER JOIN Job ON IT_Department.Job_ID = Job.Job_ID;

-- SELECT * FROM IT_Department
-- RIGHT OUTER JOIN Employee_Job ON IT_Department.Employee_ID = Employee_Job.Employee_ID
-- RIGHT OUTER JOIN Job ON Employee_Job.Job_ID = Job.Job_ID;

-- SELECT * FROM IT_Department
-- FUll OUTER JOIN Job ON IT_Department.Job_ID = Job.Job_ID;

-- SELECT * FROM IT_Department
-- FULL OUTER JOIN Employee_Job ON IT_Department.Employee_ID = Employee_Job.Employee_ID
-- FULL OUTER JOIN Job ON Employee_Job.Job_ID = Job.Job_ID;

-- SELECT UPPER(Employee_Name) FROM IT_Department;
-- SELECT LOWER(Employee_Name) FROM IT_Department;
-- SELECT UPPER(Emplayee_Name) AS UpperCase, LOWER(Employee_Name) AS LowerCase, Employee_Name FROM IT_Department;
-- SELECT SUBSTRING(Employee_Name, 1, 3) FROM IT_Department;

-- SELECT TOP 2 * FROM IT_Department;
-- SELECT * FROM IT_Department ORDER BY Employee_ID DESC;
-- SELECT TOP 4 * FROM IT_Department ORDER BY Employee_ID DESC;
-- SELECT TOP 4 * FROM IT_Department ORDER BY Employee_ID ASC;
-- Create a log table for inserts (only this new table is needed)

-- CREATE TABLE IT_Department_Log (
--     Log_ID INT IDENTITY(1,1) PRIMARY KEY,
--     Employee_ID INT,
--     Employee_Name NVARCHAR(60),
--     Action NVARCHAR(20),
--     Log_Date DATETIME DEFAULT GETDATE()
-- );

-- -- Trigger to log inserts into IT_Department
-- GO
-- CREATE TRIGGER trg_AfterInsert_IT_Department
-- ON IT_Department
-- AFTER INSERT
-- AS
-- BEGIN
--     INSERT INTO IT_Department_Log (Employee_ID, Employee_Name, Action)
--     SELECT Employee_ID, Employee_Name, 'INSERT'
--     FROM inserted;
-- END;
﻿using System.Linq.Expressions;
using System.Reflection.Metadata;
using System.Security.Cryptography.X509Certificates;
using System.IO;
using System.IO.Pipes;

namespace my_app;

class Program
{
    static void Main(string[] args)
    {
        // Console.WriteLine("My, name is Mohamehd!");

        // int age = 27;
        // string name = "Foad";
        // float salary1 = 440000.45F;
        // decimal salary2 = 488587.95M;
        // double salary3 = 45767.575D;
        // bool isstudent = true;
        // char a = 'a';

        // Console.WriteLine("enter your age");
        // int age = Convert.ToInt32(Console.ReadLine());
        // Console.WriteLine($"your age is {age}");

        // while (true)
        // {
        //     Console.WriteLine("enter your age");
        //     int age = Convert.ToInt32(Console.ReadLine());

        //     if (age <= 18)
        //     {
        //         Console.WriteLine("you are an under age");
        //     }
        //     else if (age > 18 && age <= 22)
        //     {
        //         Console.WriteLine("you are an adult");
        //     }
        //     else
        //     {
        //         Console.WriteLine("you are old as fuck");
        //     }

        //     Console.WriteLine("Press Enter to run again, or type 'exit' to quit.");
        //     if (Console.ReadLine().Trim().ToLower() == "exit")
        //     {
        //         break;
        //     }
        // }

        // for (int i = 0; i <= 10; i++)
        // {
        //     Console.WriteLine(i);
        // }

        // int i = 0;
        // do
        // {
        //     Console.WriteLine(i);
        //     i++;
        // } while (i <= 10);

        // string[] fruits = { "apple", "pineapple", "water milon" };
        // Console.WriteLine(fruits[0]);
        // foreach (string fruit in fruits)
        // {
        //     Console.WriteLine(fruit);
        // }

        // Console.WriteLine("enter your name");
        // static void Greet(string? name)
        // {
        //     Console.WriteLine($"Hello {name}");
        // }
        // Greet(Console.ReadLine());

        // Dog myDog = new Dog();
        //myDog.name = "Buddy";
        // myDog.Eat();
        // myDog.Bark();

        // Car myCar = new Car();
        // myCar.Model = "Lambo";
        // myCar.Drive();

        // Animal myAnimal = new Cat();
        // myAnimal.speak();

        // Veiachle myVeiachle = new Bicycle();
        // myVeiachle.move();

        // List<string> fruits = new List<string>();
        // fruits.Add("Apple");
        // fruits.Add("Banana");
        // fruits.Add("pineapple");

        // foreach (string fruit in fruits)
        // {
        //     Console.WriteLine(fruit);
        // }

        // Dictionary<string, int> ages = new Dictionary<string, int>();
        // ages["Alice"] = 30;
        // ages["Bob"] = 25;

        // Console.WriteLine($"Alice is {ages["Alice"]} years old.");

        // List<int> number = new List<int>();
        // number.Add(1);
        // number.Add(2);
        // number.Add(3);
        // number.Add(4);

        // int sum = number.Sum();
        // Console.WriteLine($"The sum is: {sum}");

        // Dictionary<string, string> Countries = new Dictionary<string, string>();
        // Countries["Egypt"] = "Cairo";
        // Countries["China"] = "Shanghai";

        // Console.WriteLine($"Egypt capital is {Countries["Egypt"]}");

        // try
        // {
        //     int x = int.Parse("abc");
        // }
        // catch (FormatException)
        // {
        //     Console.WriteLine("Cannot Convert to number");
        // }

        // Console.WriteLine("enter a number that should be int between 1 and 6");
        // string? number = Console.ReadLine();
        // try
        // {
        //     int numbers = int.Parse(number);
        //     Console.WriteLine($"You entered {numbers}");
        // }
        // catch (FormatException)
        // {
        //     Console.WriteLine("you entered an invalid number");
        // }

        // Console.WriteLine("Enter a number:");
        // string input = Console.ReadLine();

        // try
        // {
        //     int number = int.Parse(input);
        //     if (number > 0)
        //     {
        //         Console.WriteLine("You entered a positive number.");
        //     }
        //     else
        //     {
        //         Console.WriteLine("You entered zero or a negative number.");
        //     }
        // }
        // catch (FormatException)
        // {
        //     Console.WriteLine("That is not a valid number!");
        // }

        // File.WriteAllText(@"/home/moon/Desktop/LUNARDEV/C#_Practice/my-console-app/x.txt", "Hello!");
        // string text = File.ReadAllText("test.txt");
        // Console.WriteLine(text);

        // File.WriteAllText(@"E:\ultimate_dev\my-app\x.txt", "What's up");
        // string x = File.ReadAllText("x.txt");
        // Console.WriteLine(x);

        // Linq Queries
        // int[] numbers = { 1, 2, 3, 4, 5, 6 };
        // var evenNumbers = from n in numbers where n % 2 == 0 select n;
        // foreach (var num in evenNumbers)
        // {
        //     Console.WriteLine(num);
        // }

        // the above is same as the following
        // var evenNumbers = numbers.Where(n => n % 2 == 0);
        // foreach (var num in evenNumbers)
        // {
        //     Console.WriteLine(num);
        // }

        // int[] numbers = { 5, 10, 15, 20, 25 };
        // var bigNumbers = numbers.Where(n => n > 12);
        // foreach (var num in bigNumbers)
        // {
        //     Console.WriteLine(num);
        // }

        // List<Person> people = new List<Person>
        // {
        //     new Person { Name = "Alice", Age = 25 },
        //     new Person { Name = "Bob", Age = 30 },
        //     new Person { Name = "Charlie", Age = 28 }
        // };

        // var result = people.Where(p => p.Age > 26);
        // foreach (var person in result)
        // {
        //     Console.WriteLine(person.Name);
        // }

        List<Products> products = new List<Products>
        {
            new Products { Name = "Apple", Price = 25 },
            new Products { Name = "Pineapple", Price = 80 },
            new Products { Name = "Bananna", Price = 60 }
        };

        // var result = products.Where(p => p.Price > 50);
        // foreach (var product in result)
        // {
        //     Console.WriteLine(product.Name);
        // }

        // var names = people.Select(p => p.Name);
        // foreach (var name in names)
        // {
        //     Console.WriteLine(name);
        // }

        // var shortInfo = people.Select(p => new { p.Name, IsAdult = p.Age >= 18 });
        // foreach (var info in shortInfo)
        // {
        //     Console.WriteLine($"{info.Name} is adult ? {info.IsAdult}");
        // }

        // var prodNames = products.Select(p => p.Name);
        // foreach (var prodname in prodNames)
        // {
        //     Console.WriteLine(prodname);
        // }

        // var longInfo = products.Select(p => new { p.Name, IsExpensive = p.Price > 100 });
        // foreach (var info2 in longInfo)
        // {
        //     Console.WriteLine($"{info2.Name} is expensive ? {info2.IsExpensive}");
        // }

        // var ordered = people.OrderBy(p => p.Age);
        // foreach (var person in ordered)
        // {
        //     Console.WriteLine($"{person.Name}: {person.Age}");
        // }

        // var ordered = products.OrderBy(p => p.Price);
        // foreach (var product in ordered)
        // {
        //     Console.WriteLine($"{product.Name}: {product.Price}");
        // }

        // Aggregation (Sum, Count, Average, etc.)
        // int sum = numbers.Sum();         // Sum of all numbers
        // double average = numbers.Average(); // Average
        // int count = numbers.Count();     // Count of elements
        // int max = numbers.Max();         // Maximum

        // int totalPrice = products.Sum(p => p.Price);
        // Console.WriteLine($"Total price of all products: {totalPrice}");

        // var grouped = people.GroupBy(p => p.Age);
        // foreach (var group in grouped)
        // {
        //     Console.WriteLine($"Age: {group.Key}");
        //     foreach (var person in group)
        //     {
        //         Console.WriteLine(person.Name);
        //     }
        // }

        // var grouped = products.GroupBy(p => p.Price);
        // foreach (var group in grouped)
        // {
        //     Console.WriteLine($"Price: {group.Key}");
        //     foreach (var product in group)
        //     {
        //         Console.WriteLine(product.Name);
        //     }
        // }

        // You can chain queries:
        // var result = people
        //     .Where(p => p.Age > 20)
        //     .OrderBy(p => p.Name)
        //     .Select(p => p.Name);

        // var result2 = products
        //     .Where(p => p.Price > 20)
        //     .OrderBy(p => p.Name)
        //     .Select(p => p.Name);

        Console.ReadLine();
    }
}

class Products
{
    public string? Name { get; set; }
    public int Price { get; set; }
}

// class Person
// {
//     public string? Name { get; set; }
//     public int Age { get; set; }
// }

// class Animal
// {
//     public void Eat()
//     {
//         Console.WriteLine("Eatting");
//     }
//     public virtual void speak()
//     {
//         Console.WriteLine("Animal Sound");
//     }
// }

// class Cat : Animal
// {
//     public override void speak()
//     {
//         Console.WriteLine("Meow");
//     }
// }

// class Dog : Animal
// {
//     public string? name;

//     public void Bark()
//     {
//         Console.WriteLine(name + " says: Woof!");
//         Console.WriteLine("Woof!");
//     }
// }

// class Car
// {
//     public string? Model;

//     public void Drive()
//     {
//         Console.WriteLine($"Driving {Model}");
//     }
// }

// class Veiachle
// {
//     public virtual void move()
//     {
//         Console.WriteLine("Hello");
//     }
// }

// class Bicycle : Veiachle
// {
//     public override void move()
//     {
//         Console.WriteLine("Padaling Bike");
//     }
// }